// Blog Loader
fetch("blog-posts.json")
  .then(response => response.json())
  .then(posts => {
    const container = document.getElementById("blog-container");
    container.innerHTML = "";
    posts.forEach(post => {
      const article = document.createElement("article");
      article.innerHTML = `
        <h3>${post.title}</h3>
        <small>${post.date}</small>
        <p>${post.content}</p>
        <hr>
      `;
      container.appendChild(article);
    });
  })
  .catch(() => {
    document.getElementById("blog-container").innerText = "Failed to load posts.";
  });

// Button alert (Home Page feature)
document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("clickBtn");
  if (btn) {
    btn.addEventListener("click", () => {
      alert("Welcome to my portfolio!");
    });
  }
});
